class Student {
  final int? id;
  final String name;
  final String rollNumber;
  final String course;
  final String phone;
  final String email;
  final DateTime createdAt;

  const Student({
    this.id,
    required this.name,
    required this.rollNumber,
    required this.course,
    required this.phone,
    required this.email,
    required this.createdAt,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'name': name,
        'roll_number': rollNumber,
        'course': course,
        'phone': phone,
        'email': email,
        'created_at': createdAt.toIso8601String(),
      };

  factory Student.fromMap(Map<String, Object?> map) => Student(
        id: map['id'] as int?,
        name: map['name'] as String,
        rollNumber: map['roll_number'] as String,
        course: map['course'] as String,
        phone: map['phone'] as String,
        email: map['email'] as String,
        createdAt: DateTime.parse(map['created_at'] as String),
      );

  Student copyWith({
    int? id,
    String? name,
    String? rollNumber,
    String? course,
    String? phone,
    String? email,
    DateTime? createdAt,
  }) {
    return Student(
      id: id ?? this.id,
      name: name ?? this.name,
      rollNumber: rollNumber ?? this.rollNumber,
      course: course ?? this.course,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}
