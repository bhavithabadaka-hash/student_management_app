import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import '../models/student.dart';

class DatabaseHelper {
  DatabaseHelper._();
  static final DatabaseHelper instance = DatabaseHelper._();

  static const _databaseName = 'student_management.db';
  static const _databaseVersion = 1;
  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    final databasePath = await getDatabasesPath();
    _database = await openDatabase(
      join(databasePath, _databaseName),
      version: _databaseVersion,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            roll_number TEXT NOT NULL UNIQUE,
            course TEXT NOT NULL,
            phone TEXT NOT NULL,
            email TEXT NOT NULL,
            created_at TEXT NOT NULL
          )
        ''');
      },
    );
    return _database!;
  }

  Future<List<Student>> getStudents({String search = ''}) async {
    final db = await database;
    final trimmed = search.trim();
    final rows = await db.query(
      'students',
      where: trimmed.isEmpty
          ? null
          : 'name LIKE ? OR roll_number LIKE ? OR course LIKE ?',
      whereArgs: trimmed.isEmpty
          ? null
          : ['%$trimmed%', '%$trimmed%', '%$trimmed%'],
      orderBy: 'name COLLATE NOCASE ASC',
    );
    return rows.map(Student.fromMap).toList();
  }

  Future<int> insertStudent(Student student) async {
    final db = await database;
    return db.insert(
      'students',
      student.toMap()..remove('id'),
      conflictAlgorithm: ConflictAlgorithm.abort,
    );
  }

  Future<int> updateStudent(Student student) async {
    final db = await database;
    if (student.id == null) {
      throw ArgumentError('Student ID is required for an update.');
    }
    return db.update(
      'students',
      student.toMap()..remove('id'),
      where: 'id = ?',
      whereArgs: [student.id],
      conflictAlgorithm: ConflictAlgorithm.abort,
    );
  }

  Future<int> deleteStudent(int id) async {
    final db = await database;
    return db.delete('students', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> getStudentCount() async {
    final db = await database;
    final result = await db.rawQuery('SELECT COUNT(*) AS total FROM students');
    return Sqflite.firstIntValue(result) ?? 0;
  }

  Future<void> close() async {
    await _database?.close();
    _database = null;
  }
}
