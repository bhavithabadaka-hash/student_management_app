import 'package:flutter_test/flutter_test.dart';
import 'package:student_management_app/main.dart';

void main() {
  testWidgets('Student management app starts', (tester) async {
    await tester.pumpWidget(const StudentManagementApp());
    expect(find.text('Student Manager'), findsOneWidget);
    expect(find.text('Student Dashboard'), findsOneWidget);
  });
}
